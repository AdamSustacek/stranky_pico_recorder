@echo off
cd /d "%~dp0\app"
python app.py
pause
