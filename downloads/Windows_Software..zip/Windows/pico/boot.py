# boot.py – spustí se před main.py, nastavuje USB deskriptory
# Musí být uložen jako /boot.py na CIRCUITPY drive
import usb_cdc
usb_cdc.enable(console=True, data=True)
