# ============================================================
#  Pico Audio Recorder – main.py  v3.0
#  CircuitPython 10.2.1 | RP2040
#  Mikrofon: Adafruit SPH0645 I2S MEMS
#  BCLK → GP0 | DOUT → GP1 | LRCLK → GP2
#  LED záznam → GP18 | LED power → GP16
#  Button START → GP22 | Button STOP → GP21
#  Data přes USB CDC (ACM1) – PCM s16le, 16000 Hz, mono
# ============================================================

import time
import json
import array
import board
import digitalio
import audiobusio
import usb_cdc

# ── Konfigurace ──────────────────────────────────────────────
SAMPLE_RATE   = 16000
NUM_CHANNELS  = 1
CHUNK_SAMPLES = 256
HEADER_MAGIC  = b"PCM1"

# ── Piny ─────────────────────────────────────────────────────
led_rec   = digitalio.DigitalInOut(board.GP18)
led_power = digitalio.DigitalInOut(board.GP16)
btn_start = digitalio.DigitalInOut(board.GP22)
btn_stop  = digitalio.DigitalInOut(board.GP21)

led_rec.direction   = digitalio.Direction.OUTPUT
led_power.direction = digitalio.Direction.OUTPUT
btn_start.direction = digitalio.Direction.INPUT
btn_stop.direction  = digitalio.Direction.INPUT
btn_start.pull      = digitalio.Pull.UP
btn_stop.pull       = digitalio.Pull.UP

# ── I2S mikrofon SPH0645 ─────────────────────────────────────
# PDMIn čte I2S data: clock=GP0, data=GP1
mic = audiobusio.PDMIn(
    clock_pin   = board.GP0,
    data_pin    = board.GP1,
    sample_rate = SAMPLE_RATE,
    bit_depth   = 16,
)

# Buffer – unsigned 16bit
samples = array.array("H", [0] * CHUNK_SAMPLES)

# ── USB datový port ───────────────────────────────────────────
data_port = usb_cdc.data
data_port.timeout = 0

# ── Stav ─────────────────────────────────────────────────────
recording  = False
led_state  = False
last_blink = 0
cmd_buf    = bytearray()

# ── Funkce ───────────────────────────────────────────────────

def send_json(obj):
    data_port.write((json.dumps(obj) + "\n").encode("utf-8"))


def read_commands():
    global cmd_buf
    cmds = []
    n = data_port.in_waiting
    if n:
        cmd_buf += data_port.read(n)
        while b"\n" in cmd_buf:
            idx = cmd_buf.index(b"\n")
            line = cmd_buf[:idx].decode("utf-8", "ignore").strip()
            cmd_buf = cmd_buf[idx + 1:]
            if line:
                cmds.append(line)
    return cmds


def process_commands(cmds):
    global recording
    for raw in cmds:
        try:
            obj = json.loads(raw)
            cmd = obj.get("cmd", "")
            if cmd == "start" and not recording:
                recording = True
                send_json({"event": "started", "sample_rate": SAMPLE_RATE,
                           "bits": 16, "channels": 1, "endian": "little"})
            elif cmd == "stop" and recording:
                recording = False
                send_json({"event": "stopped"})
            elif cmd == "ping":
                send_json({"event": "pong", "sample_rate": SAMPLE_RATE,
                           "firmware": "3.0"})
        except (ValueError, KeyError):
            pass


def record_chunk():
    """
    SPH0645 přes PDMIn vrací unsigned 16bit hodnoty.
    Střed signálu je na 32768 (0x8000).
    Převedeme na signed: odečteme 32768.
    Výsledek odešleme jako little-endian s16.
    """
    mic.record(samples, len(samples))

    buf = bytearray(CHUNK_SAMPLES * 2)
    for i in range(CHUNK_SAMPLES):
        # unsigned 16bit → signed 16bit (odečti střed)
        val = samples[i] - 32768
        # little-endian zápis
        buf[i * 2]     =  val & 0xFF
        buf[i * 2 + 1] = (val >> 8) & 0xFF

    data_port.write(HEADER_MAGIC)
    data_port.write(buf)


# ── Start ─────────────────────────────────────────────────────
led_power.value = True
send_json({"event": "ready", "sample_rate": SAMPLE_RATE,
           "firmware": "3.0", "chip": "SPH0645"})
print("Pico Audio Recorder v3.0 | I2S SPH0645 | SR:", SAMPLE_RATE)

# ── Hlavní smyčka ─────────────────────────────────────────────
while True:
    now = time.monotonic_ns()

    # Blikání LED
    if recording:
        if now - last_blink >= 500_000_000:
            led_state = not led_state
            led_rec.value = led_state
            last_blink = now
    else:
        led_rec.value = False
        led_state = False

    # Tlačítka
    if not btn_start.value and not recording:
        time.sleep(0.05)
        if not btn_start.value:
            process_commands(['{"cmd":"start"}'])

    if not btn_stop.value and recording:
        time.sleep(0.05)
        if not btn_stop.value:
            process_commands(['{"cmd":"stop"}'])

    # USB příkazy
    cmds = read_commands()
    if cmds:
        process_commands(cmds)

    # Nahrávání
    if recording:
        record_chunk()
