# ============================================================
#  app.py – Pico Audio Recorder
#  Kombinovaná aplikace: diagnostika + nahrávání v jednom okně
#  Funguje na Windows i Linux
#  Auto-detekce Pica při připojení
# ============================================================

import tkinter as tk
from tkinter import messagebox
import threading
import queue
import time
import os
import glob
import platform
import subprocess
import sys
import serial

from config import *
from serial_manager import SerialManager, find_pico_ports, list_all_ports
from audio_engine import AudioEngine

IS_WINDOWS = platform.system() == "Windows"

# ── Stránky aplikace ─────────────────────────────────────────
PAGE_DIAG = "diag"
PAGE_REC  = "rec"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Pico Audio Recorder")
        self.configure(bg=C_BG)
        self.resizable(False, False)

        # ── Fronta pro thread-safe GUI volání ─────────────
        self._q    = queue.Queue()
        self._page = PAGE_DIAG

        # ── Sub-moduly ────────────────────────────────────
        self._audio = AudioEngine(
            on_vu    = self._enq(self._on_vu),
            on_saved = self._enq(self._on_saved),
            on_error = self._enq(self._on_error),
        )
        self._serial = SerialManager(
            on_audio  = self._audio.feed,
            on_event  = self._enq(self._on_event),
            on_status = self._enq(self._on_status),
        )

        # ── Stav ──────────────────────────────────────────
        self._connected   = False
        self._recording   = False
        self._rec_start   = 0.0
        self._vu_val      = 0.0
        self._last_save   = ""
        self._watch_ports = set()

        # ── UI ────────────────────────────────────────────
        self._build_header()
        self._build_diag_page()
        self._build_rec_page()
        self._build_statusbar()

        self._show_page(PAGE_DIAG)

        # ── Smyčky ────────────────────────────────────────
        self._poll_queue()
        self._tick()
        self._watch_pico()

        self.protocol("WM_DELETE_WINDOW", self._on_close)


    # ═══════════════════════════════════════════════════════
    #  Thread-safe helper
    # ═══════════════════════════════════════════════════════

    def _enq(self, fn):
        def wrapper(*args, **kwargs):
            self._q.put((fn, args, kwargs))
        return wrapper

    def _poll_queue(self):
        try:
            for _ in range(30):
                fn, a, kw = self._q.get_nowait()
                fn(*a, **kw)
        except queue.Empty:
            pass
        self.after(15, self._poll_queue)

    # ═══════════════════════════════════════════════════════
    #  Stavění UI
    # ═══════════════════════════════════════════════════════

    def _build_header(self):
        self._hdr = tk.Frame(self, bg=C_PANEL)
        self._hdr.pack(fill="x")

        # Logo + název
        left = tk.Frame(self._hdr, bg=C_PANEL, padx=16, pady=12)
        left.pack(side="left")
        tk.Label(left, text="⬤", bg=C_PANEL, fg=C_ACCENT,
                 font=("DejaVu Sans", 18)).pack(side="left")
        tk.Label(left, text=" PICO RECORDER", bg=C_PANEL, fg=C_TEXT,
                 font=F_TITLE).pack(side="left")

        # Navigace
        right = tk.Frame(self._hdr, bg=C_PANEL, padx=16)
        right.pack(side="right")

        self._tab_diag = self._nav_btn(right, "⚙  Diagnostika",
                                        lambda: self._show_page(PAGE_DIAG))
        self._tab_diag.pack(side="left", padx=4)

        self._tab_rec = self._nav_btn(right, "⏺  Nahrávání",
                                       lambda: self._show_page(PAGE_REC))
        self._tab_rec.pack(side="left", padx=4)

        tk.Frame(self, bg=C_BORDER, height=1).pack(fill="x")

    def _nav_btn(self, parent, text, cmd):
        return tk.Button(
            parent, text=text, command=cmd,
            bg=C_PANEL, fg=C_DIM, font=F_UI,
            relief="flat", bd=0, padx=12, pady=8,
            cursor="hand2",
            activebackground=C_BORDER, activeforeground=C_TEXT,
        )

    # ─── Diagnostická stránka ────────────────────────────────

    def _build_diag_page(self):
        self._diag_frame = tk.Frame(self, bg=C_BG)

        # Krok indikátory
        steps_outer = tk.Frame(self._diag_frame, bg=C_BG, padx=24, pady=16)
        steps_outer.pack(fill="x")

        self._steps = []
        step_labels = [
            ("Detekce portů",       "Hledám Pico na USB portů…"),
            ("Oprávnění",           "Kontroluji přístup k portu…"),
            ("Komunikace",          "Testuji ping/pong s Picem…"),
            ("Výsledek",            "Vyhodnocuji…"),
        ]
        for i, (title, _) in enumerate(step_labels):
            row = tk.Frame(steps_outer, bg=C_BG, pady=5)
            row.pack(fill="x")

            dot = tk.Label(row, text="○", bg=C_BG, fg=C_DIM,
                           font=("DejaVu Sans", 16), width=2)
            dot.pack(side="left")

            inner = tk.Frame(row, bg=C_BG)
            inner.pack(side="left", fill="x", expand=True, padx=8)

            tk.Label(inner, text=f"{i+1}. {title}", bg=C_BG, fg=C_TEXT,
                     font=F_BOLD, anchor="w").pack(fill="x")

            sub = tk.Label(inner, text="čekám…", bg=C_BG, fg=C_DIM,
                           font=F_UI, anchor="w")
            sub.pack(fill="x")

            self._steps.append((dot, sub))

        tk.Frame(self._diag_frame, bg=C_BORDER, height=1).pack(fill="x")

        # Log
        log_frame = tk.Frame(self._diag_frame, bg=C_PANEL, padx=16, pady=10)
        log_frame.pack(fill="both", expand=True)

        self._diag_log = tk.Text(
            log_frame, height=8, bg=C_PANEL, fg=C_TEXT,
            font=F_MONO, bd=0, state="disabled", wrap="word",
            selectbackground=C_BORDER,
        )
        self._diag_log.pack(fill="both", expand=True)
        self._diag_log.tag_config("ok",   foreground=C_GREEN)
        self._diag_log.tag_config("err",  foreground=C_RED)
        self._diag_log.tag_config("warn", foreground=C_YELLOW)
        self._diag_log.tag_config("info", foreground=C_ACCENT)
        self._diag_log.tag_config("dim",  foreground=C_DIM)

        tk.Frame(self._diag_frame, bg=C_BORDER, height=1).pack(fill="x")

        # Spodní lišta diagnostiky
        bot = tk.Frame(self._diag_frame, bg=C_BG, padx=16, pady=12)
        bot.pack(fill="x")

        self._diag_result = tk.Label(
            bot, text="Připoj Pico přes USB…",
            bg=C_BG, fg=C_DIM, font=F_BOLD, anchor="w"
        )
        self._diag_result.pack(side="left", fill="x", expand=True)

        self._btn_retry = self._mk_btn(
            bot, "↺  Opakovat", self._start_diag,
            bg=C_PANEL, fg=C_TEXT, state="normal"
        )
        self._btn_retry.pack(side="right", padx=(8, 0))

        self._btn_go = self._mk_btn(
            bot, "▶  Přejít na nahrávání", self._go_record,
            bg=C_ACCENT, fg=C_BG, state="disabled"
        )
        self._btn_go.pack(side="right")

    # ─── Nahrávací stránka ───────────────────────────────────

    def _build_rec_page(self):
        self._rec_frame = tk.Frame(self, bg=C_BG)

        # Stav připojení
        conn_bar = tk.Frame(self._rec_frame, bg=C_PANEL, padx=16, pady=8)
        conn_bar.pack(fill="x")

        tk.Label(conn_bar, text="Port:", bg=C_PANEL, fg=C_DIM,
                 font=F_UI).pack(side="left")

        self._port_var   = tk.StringVar(value=DATA_PORT)
        ports            = list_all_ports() or [DATA_PORT]
        self._port_combo = tk.OptionMenu(conn_bar, self._port_var, *ports)
        self._port_combo.config(
            bg=C_BORDER, fg=C_TEXT, font=F_MONO,
            relief="flat", bd=0, highlightthickness=0,
            activebackground=C_BORDER, activeforeground=C_TEXT,
        )
        self._port_combo["menu"].config(
            bg=C_PANEL, fg=C_TEXT, font=F_MONO,
            relief="flat", bd=0,
        )
        self._port_combo.pack(side="left", padx=8)

        self._conn_dot = tk.Label(
            conn_bar, text="●", bg=C_PANEL, fg=C_DIM,
            font=("DejaVu Sans", 18)
        )
        self._conn_dot.pack(side="left")

        self._btn_connect = self._mk_btn(
            conn_bar, "Připojit", self._toggle_connect,
            bg=C_ACCENT, fg=C_BG
        )
        self._btn_connect.pack(side="right")

        tk.Frame(self._rec_frame, bg=C_BORDER, height=1).pack(fill="x")

        # Timer
        timer_frame = tk.Frame(self._rec_frame, bg=C_BG, pady=20)
        timer_frame.pack()

        self._timer_lbl = tk.Label(
            timer_frame, text="00:00:00",
            bg=C_BG, fg=C_DIM, font=F_TIMER
        )
        self._timer_lbl.pack()

        # VU metr
        vu_frame = tk.Frame(self._rec_frame, bg=C_BG, padx=24)
        vu_frame.pack(fill="x")

        tk.Label(vu_frame, text="VU", bg=C_BG, fg=C_DIM,
                 font=F_UI, width=3).pack(side="left")

        self._vu_canvas = tk.Canvas(
            vu_frame, height=20, bg=C_PANEL,
            bd=0, highlightthickness=1,
            highlightbackground=C_BORDER
        )
        self._vu_canvas.pack(side="left", fill="x", expand=True, padx=(8, 0))

        tk.Frame(self._rec_frame, bg=C_BG, height=16).pack()

        # START / STOP
        ctrl = tk.Frame(self._rec_frame, bg=C_BG)
        ctrl.pack()

        self._btn_start = tk.Button(
            ctrl, text="▶   START",
            command=self._do_start,
            bg=C_ACCENT, fg=C_BG,
            font=("DejaVu Sans", 13, "bold"),
            relief="flat", bd=0, padx=28, pady=14,
            cursor="hand2", state="disabled",
            activebackground=C_ACCENT, activeforeground=C_BG,
        )
        self._btn_start.grid(row=0, column=0, padx=12)

        self._btn_stop = tk.Button(
            ctrl, text="■   STOP",
            command=self._do_stop,
            bg=C_RED, fg=C_BG,
            font=("DejaVu Sans", 13, "bold"),
            relief="flat", bd=0, padx=28, pady=14,
            cursor="hand2", state="disabled",
            activebackground=C_RED, activeforeground=C_BG,
        )
        self._btn_stop.grid(row=0, column=1, padx=12)

        tk.Frame(self._rec_frame, bg=C_BG, height=16).pack()
        tk.Frame(self._rec_frame, bg=C_BORDER, height=1).pack(fill="x")

        # Poslední nahrávka
        save_frame = tk.Frame(self._rec_frame, bg=C_BG, padx=16, pady=8)
        save_frame.pack(fill="x")

        tk.Label(save_frame, text="Uloženo:", bg=C_BG, fg=C_DIM,
                 font=F_UI).pack(side="left")

        self._save_lbl = tk.Label(
            save_frame, text="—", bg=C_BG, fg=C_TEXT,
            font=F_MONO, cursor="hand2"
        )
        self._save_lbl.pack(side="left", padx=6)
        self._save_lbl.bind("<Button-1>", self._open_folder)

    # ─── Statusbar ───────────────────────────────────────────

    def _build_statusbar(self):
        tk.Frame(self, bg=C_BORDER, height=1).pack(fill="x")
        self._status_lbl = tk.Label(
            self, text="Připoj Pico přes USB",
            bg=C_BG, fg=C_DIM, font=F_UI, anchor="w",
            padx=16, pady=6
        )
        self._status_lbl.pack(fill="x")

    # ─── Pomocný builder tlačítek ────────────────────────────

    def _mk_btn(self, parent, text, cmd, bg=C_PANEL, fg=C_TEXT,
                state="normal"):
        return tk.Button(
            parent, text=text, command=cmd,
            bg=bg, fg=fg, font=F_BOLD,
            relief="flat", bd=0, padx=14, pady=7,
            cursor="hand2", state=state,
            activebackground=bg, activeforeground=fg,
        )

    # ═══════════════════════════════════════════════════════
    #  Navigace mezi stránkami
    # ═══════════════════════════════════════════════════════

    def _show_page(self, page):
        self._page = page
        self._diag_frame.pack_forget()
        self._rec_frame.pack_forget()

        if page == PAGE_DIAG:
            self._diag_frame.pack(fill="both", expand=True)
            self._tab_diag.config(fg=C_ACCENT, bg=C_BORDER)
            self._tab_rec.config(fg=C_DIM, bg=C_PANEL)
        else:
            self._rec_frame.pack(fill="both", expand=True)
            self._tab_rec.config(fg=C_ACCENT, bg=C_BORDER)
            self._tab_diag.config(fg=C_DIM, bg=C_PANEL)

    def _go_record(self):
        self._show_page(PAGE_REC)

    # ═══════════════════════════════════════════════════════
    #  Auto-detekce Pica
    # ═══════════════════════════════════════════════════════

    def _watch_pico(self):
        """Sleduje USB porty a automaticky spustí diagnostiku."""
        def _check():
            current = set(list_all_ports())
            if current != self._watch_ports:
                new = current - self._watch_ports
                self._watch_ports = current
                if new and not self._connected:
                    # Nový port přibyl → spusť diagnostiku
                    self._enq(self._auto_diag)()
            self.after(1500, _check)

        # Inicializuj seznam portů
        self._watch_ports = set(list_all_ports())
        self.after(1500, _check)

    def _auto_diag(self):
        """Automaticky spuštěná diagnostika po detekci Pica."""
        self._show_page(PAGE_DIAG)
        self._dlog("🔌 Detekováno nové zařízení — spouštím diagnostiku…\n", "info")
        self.after(800, self._start_diag)

    # ═══════════════════════════════════════════════════════
    #  Diagnostika
    # ═══════════════════════════════════════════════════════

    def _start_diag(self):
        """Resetuje UI a spustí diagnostiku v pozadí."""
        for dot, sub in self._steps:
            dot.config(text="○", fg=C_DIM)
            sub.config(text="čekám…", fg=C_DIM)
        self._btn_go.config(state="disabled")
        self._diag_result.config(text="Probíhá diagnostika…", fg=C_DIM)
        self._dlog_clear()
        threading.Thread(target=self._diag_thread, daemon=True).start()

    def _diag_thread(self):
        import glob as _glob

        # ── Krok 1: Porty ────────────────────────────────
        self._step_run(0)
        all_ports = list_all_ports()

        if not all_ports:
            self._step_fail(0, "žádné porty")
            self._dlog("❌ Žádné porty – připoj Pico přes USB\n", "err")
            self._diag_done(False, "Pico není připojeno")
            return

        self._step_ok(0, ", ".join(all_ports))
        self._dlog(f"✅ Porty: {', '.join(all_ports)}\n", "ok")

        # ── Krok 2: Oprávnění ─────────────────────────────
        self._step_run(1)
        if not IS_WINDOWS:
            bad = [p for p in all_ports if not os.access(p, os.R_OK | os.W_OK)]
            if bad:
                self._step_fail(1, "chybí oprávnění")
                self._dlog(f"❌ Nemáš přístup na: {', '.join(bad)}\n", "err")
                self._dlog("   Spusť: sudo usermod -aG dialout $USER\n", "warn")
                self._dlog("   Pak se odhlásit a přihlásit!\n", "dim")
                self._diag_done(False, "Chybí oprávnění")
                return
        self._step_ok(1, "OK")
        self._dlog("✅ Oprávnění OK\n", "ok")

        # ── Krok 3: Ping ──────────────────────────────────
        self._step_run(2)
        self._dlog("\nTestuji komunikaci…\n", "info")
        found = None

        for port in all_ports:
            self._dlog(f"\n→ {port}…\n", "dim")
            try:
                import serial as _serial
                s = _serial.Serial(port, 115200, timeout=0)
                time.sleep(0.5)
                s.reset_input_buffer()
                s.write(b'{"cmd":"ping"}\n')
                time.sleep(1.5)
                data = s.read(s.in_waiting)
                s.close()

                if data:
                    text = data.decode("utf-8", "ignore").strip()
                    self._dlog(f"   {text}\n", "ok")
                    if any(k in text for k in ("pong", "ready", "sample_rate")):
                        found = port
                        self._dlog(f"✅ Datový port: {port}\n", "ok")
                        break
                else:
                    self._dlog("   ⚠️  Žádná odpověď\n", "warn")
            except Exception as e:
                self._dlog(f"   ❌ {e}\n", "err")

        if found:
            self._step_ok(2, f"Pico na {found}")
            # Ulož port do config a port_var
            self._enq(lambda p=found: self._port_var.set(p))()
        else:
            self._step_fail(2, "neodpovídá")
            self._dlog("\n❌ Pico neodpovídá\n", "err")
            self._dlog("   • Zkontroluj boot.py na Picu\n", "dim")
            self._dlog("   • Zkontroluj že běží main.py (Thonny)\n", "dim")

        # ── Krok 4: Výsledek ──────────────────────────────
        self._step_run(3)
        if found:
            self._step_ok(3, "vše OK")
            self._diag_done(True, f"Pico připraveno na {found}")
        else:
            self._step_fail(3, "selhalo")
            self._diag_done(False, "Pico nenalezeno")

    # ── Diagnostika helpers ──────────────────────────────────

    def _step_run(self, i):
        dot, sub = self._steps[i]
        self.after(0, lambda: dot.config(text="◉", fg=C_ACCENT))
        self.after(0, lambda: sub.config(text="probíhá…", fg=C_ACCENT))

    def _step_ok(self, i, msg=""):
        dot, sub = self._steps[i]
        self.after(0, lambda: dot.config(text="●", fg=C_GREEN))
        self.after(0, lambda: sub.config(text=msg, fg=C_GREEN))

    def _step_fail(self, i, msg=""):
        dot, sub = self._steps[i]
        self.after(0, lambda: dot.config(text="●", fg=C_RED))
        self.after(0, lambda: sub.config(text=msg, fg=C_RED))

    def _diag_done(self, ok, msg):
        def _do():
            if ok:
                self._diag_result.config(text=f"✅ {msg}", fg=C_GREEN)
                self._btn_go.config(state="normal")
            else:
                self._diag_result.config(text=f"❌ {msg}", fg=C_RED)
        self.after(0, _do)

    def _dlog(self, msg, tag=""):
        def _do():
            self._diag_log.config(state="normal")
            if tag:
                self._diag_log.insert("end", msg, tag)
            else:
                self._diag_log.insert("end", msg)
            self._diag_log.see("end")
            self._diag_log.config(state="disabled")
        self.after(0, _do)

    def _dlog_clear(self):
        self._diag_log.config(state="normal")
        self._diag_log.delete("1.0", "end")
        self._diag_log.config(state="disabled")

    # ═══════════════════════════════════════════════════════
    #  Připojení / Odpojení
    # ═══════════════════════════════════════════════════════

    def _toggle_connect(self):
        if self._connected:
            self._disconnect()
        else:
            self._connect()

    def _connect(self):
        port = self._port_var.get()
        ok   = self._serial.connect(port)
        if ok:
            self._connected = True
            self._btn_connect.config(text="Odpojit", bg=C_RED)
            self._conn_dot.config(fg=C_GREEN)
            self._update_btns()
            # Diagnostika po připojení
            self.after(1000, lambda: self._serial.send('{"cmd":"ping"}'))

    def _disconnect(self):
        if self._recording:
            self._do_stop()
        self._serial.disconnect()
        self._connected = False
        self._btn_connect.config(text="Připojit", bg=C_ACCENT)
        self._conn_dot.config(fg=C_DIM)
        self._update_btns()

    # ═══════════════════════════════════════════════════════
    #  Nahrávání
    # ═══════════════════════════════════════════════════════

    def _do_start(self):
        if not self._connected or self._recording:
            return
        self._recording = True
        self._rec_start = time.time()
        self._audio.start()
        self._serial.send('{"cmd":"start"}')
        self._update_btns()
        self._status("● Nahrávám…", C_RED)

    def _do_stop(self):
        if not self._recording:
            return
        self._recording = False
        self._serial.send('{"cmd":"stop"}')
        self._audio.stop()
        self._update_btns()
        self._status("Ukládám MP3…", C_DIM)

    def _update_btns(self):
        conn = self._connected
        rec  = self._recording
        self._btn_start.config(
            state="normal" if (conn and not rec) else "disabled")
        self._btn_stop.config(
            state="normal" if (conn and rec) else "disabled")

    # ═══════════════════════════════════════════════════════
    #  Callbacks
    # ═══════════════════════════════════════════════════════

    def _on_vu(self, level):
        self._vu_val = level
        self._draw_vu(level)

    def _on_event(self, ev):
        e = ev.get("event", "")
        if e == "ready":
            self._status(
                f"Pico připraveno | SR={ev.get('sample_rate')} Hz | FW={ev.get('firmware')}",
                C_GREEN
            )
        elif e == "started":
            self._status("● Nahrávám…", C_RED)
        elif e == "stopped":
            self._status("Zastaveno", C_DIM)

    def _on_status(self, msg):
        self._status(msg, C_DIM)

    def _on_saved(self, path):
        self._last_save = path
        self._save_lbl.config(text=os.path.basename(path), fg=C_ACCENT)
        self._status(f"✅ Uloženo: {path}", C_GREEN)

    def _on_error(self, msg):
        self._status(f"❌ {msg}", C_RED)
        messagebox.showerror("Chyba", msg)

    def _status(self, msg, color=None):
        self._status_lbl.config(text=msg)
        if color:
            self._status_lbl.config(fg=color)

    # ═══════════════════════════════════════════════════════
    #  VU metr + Timer
    # ═══════════════════════════════════════════════════════

    def _draw_vu(self, level):
        c   = self._vu_canvas
        w   = c.winfo_width()
        h   = c.winfo_height()
        if w < 2:
            return
        c.delete("all")
        bars   = VU_BARS
        gap    = 3
        bar_w  = max(1, (w - gap * (bars - 1)) // bars)
        filled = int(level * bars)

        for i in range(bars):
            x1 = i * (bar_w + gap)
            x2 = x1 + bar_w
            if i < filled:
                r = i / bars
                color = C_GREEN if r < 0.6 else (C_YELLOW if r < 0.85 else C_RED)
            else:
                color = C_BORDER
            c.create_rectangle(x1, 1, x2, h - 1, fill=color, outline="")

    def _tick(self):
        if self._recording:
            e = time.time() - self._rec_start
            h, m, s = int(e // 3600), int((e % 3600) // 60), int(e % 60)
            self._timer_lbl.config(
                text=f"{h:02d}:{m:02d}:{s:02d}", fg=C_RED)
        else:
            self._timer_lbl.config(fg=C_DIM)
            if self._vu_val > 0:
                self._vu_val *= 0.88
                self._draw_vu(self._vu_val)
        self.after(200, self._tick)

    # ═══════════════════════════════════════════════════════
    #  Otevření složky
    # ═══════════════════════════════════════════════════════

    def _open_folder(self, _=None):
        folder = RECORDINGS_DIR
        if not os.path.isdir(folder):
            messagebox.showinfo("Info", f"Složka ještě neexistuje:\n{folder}")
            return
        if IS_WINDOWS:
            os.startfile(folder)
        else:
            subprocess.Popen(["xdg-open", folder])

    # ═══════════════════════════════════════════════════════
    #  Zavření
    # ═══════════════════════════════════════════════════════

    def _on_close(self):
        if self._recording:
            self._do_stop()
        self._serial.disconnect()
        self.destroy()


# ── Spuštění ─────────────────────────────────────────────────
if __name__ == "__main__":
    app = App()
    app.update_idletasks()
    w, h   = app.winfo_reqwidth(), app.winfo_reqheight()
    sw, sh = app.winfo_screenwidth(), app.winfo_screenheight()
    app.geometry(f"560x680+{(sw-560)//2}+{(sh-680)//2}")
    app.mainloop()
