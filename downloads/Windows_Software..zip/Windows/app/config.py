# ============================================================
#  config.py – automatická konfigurace pro Linux i Windows
# ============================================================

import os
import sys
import shutil
import platform

# ── Detekce OS ───────────────────────────────────────────────
IS_WINDOWS = platform.system() == "Windows"
IS_LINUX   = platform.system() == "Linux"

# ── Sériový port ─────────────────────────────────────────────
# Nastavuje se automaticky při detekci Pica
# Výchozí hodnoty:
DATA_PORT = "COM4" if IS_WINDOWS else "/dev/ttyACM1"
BAUD_RATE = 115200

# ── Audio ────────────────────────────────────────────────────
SAMPLE_RATE   = 16000
CHANNELS      = 1
SAMPLE_WIDTH  = 2
CHUNK_HEADER  = b"PCM1"
CHUNK_SAMPLES = 256
CHUNK_BYTES   = CHUNK_SAMPLES * SAMPLE_WIDTH

# ── Cesty ────────────────────────────────────────────────────
if IS_WINDOWS:
    RECORDINGS_DIR = os.path.join(os.path.expanduser("~"), "PicoNahravky")
else:
    RECORDINGS_DIR = os.path.join(os.path.expanduser("~"), "PicoNahravky")

# ffmpeg – automatické hledání
def _find_ffmpeg():
    # Zkus PATH
    found = shutil.which("ffmpeg")
    if found:
        return found
    # Windows fallback – WinGet cesta
    if IS_WINDOWS:
        import glob
        pattern = os.path.expanduser(
            r"~\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg*\**\ffmpeg.exe"
        )
        matches = glob.glob(pattern, recursive=True)
        if matches:
            return matches[0]
    return "ffmpeg"   # doufáme že je v PATH

FFMPEG_PATH = _find_ffmpeg()

# ── VU metr ──────────────────────────────────────────────────
VU_DECAY = 0.85
VU_BARS  = 20

# ── Paleta ───────────────────────────────────────────────────
C_BG      = "#0d0f14"
C_PANEL   = "#141820"
C_BORDER  = "#1e2535"
C_ACCENT  = "#00c2ff"
C_RED     = "#ff3e6c"
C_GREEN   = "#00d97e"
C_YELLOW  = "#f0b400"
C_TEXT    = "#e8eaf0"
C_DIM     = "#5a6070"

# ── Fonty ────────────────────────────────────────────────────
if IS_WINDOWS:
    F_UI    = ("Segoe UI", 10)
    F_BOLD  = ("Segoe UI", 10, "bold")
    F_MONO  = ("Consolas", 10)
    F_TITLE = ("Segoe UI", 13, "bold")
    F_TIMER = ("Consolas", 30, "bold")
else:
    F_UI    = ("DejaVu Sans", 10)
    F_BOLD  = ("DejaVu Sans", 10, "bold")
    F_MONO  = ("DejaVu Sans Mono", 10)
    F_TITLE = ("DejaVu Sans", 13, "bold")
    F_TIMER = ("DejaVu Sans Mono", 30, "bold")
