# ============================================================
#  audio_engine.py – PCM buffer, VU metr, export MP3
# ============================================================

import wave
import struct
import subprocess
import os
import math
import datetime
import threading

from config import (
    SAMPLE_RATE, CHANNELS, SAMPLE_WIDTH,
    CHUNK_SAMPLES, FFMPEG_PATH, RECORDINGS_DIR, VU_DECAY
)


class AudioEngine:

    def __init__(self, on_vu=None, on_saved=None, on_error=None):
        self.on_vu    = on_vu
        self.on_saved = on_saved
        self.on_error = on_error

        self._chunks   = []
        self._n_samp   = 0
        self._rec      = False
        self._vu_peak  = 0.0
        self._lock     = threading.Lock()

    def start(self):
        with self._lock:
            self._chunks  = []
            self._n_samp  = 0
            self._rec     = True
            self._vu_peak = 0.0

    def stop(self):
        with self._lock:
            self._rec   = False
            chunks      = list(self._chunks)
            n           = self._n_samp
        if not chunks:
            if self.on_error:
                self.on_error("Žádná audio data.")
            return
        threading.Thread(
            target=self._export, args=(chunks, n), daemon=True
        ).start()

    def feed(self, pcm: bytes):
        with self._lock:
            if not self._rec:
                return
            self._chunks.append(pcm)
            self._n_samp += len(pcm) // SAMPLE_WIDTH
        self._vu(pcm)

    def duration(self) -> float:
        with self._lock:
            return self._n_samp / SAMPLE_RATE

    def is_recording(self) -> bool:
        with self._lock:
            return self._rec

    def get_vu(self) -> float:
        with self._lock:
            return self._vu_peak

    def _vu(self, pcm: bytes):
        n = len(pcm) // SAMPLE_WIDTH
        if not n:
            return
        samples = struct.unpack(f"<{n}h", pcm[:n * SAMPLE_WIDTH])
        rms = math.sqrt(sum(s * s for s in samples) / n) / 32768.0
        with self._lock:
            if rms > self._vu_peak:
                self._vu_peak = rms
            else:
                self._vu_peak *= VU_DECAY
            peak = self._vu_peak
        if self.on_vu:
            self.on_vu(peak)

    def _export(self, chunks, n_samp):
        os.makedirs(RECORDINGS_DIR, exist_ok=True)
        ts       = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        wav_path = os.path.join(RECORDINGS_DIR, f"nahravka_{ts}.wav")
        mp3_path = os.path.join(RECORDINGS_DIR, f"nahravka_{ts}.mp3")

        # WAV
        try:
            with wave.open(wav_path, "wb") as wf:
                wf.setnchannels(CHANNELS)
                wf.setsampwidth(SAMPLE_WIDTH)
                wf.setframerate(SAMPLE_RATE)
                for c in chunks:
                    wf.writeframes(c)
        except Exception as e:
            if self.on_error:
                self.on_error(f"WAV chyba: {e}")
            return

        # MP3
        try:
            r = subprocess.run(
                [FFMPEG_PATH, "-y", "-i", wav_path,
                 "-ar", str(SAMPLE_RATE), "-ac", str(CHANNELS),
                 "-q:a", "4", mp3_path],
                capture_output=True, timeout=60
            )
            if r.returncode != 0:
                raise RuntimeError(r.stderr.decode("utf-8", "ignore"))
            os.remove(wav_path)
            if self.on_saved:
                self.on_saved(mp3_path)
        except Exception as e:
            if self.on_error:
                self.on_error(f"ffmpeg chyba: {e}\nWAV: {wav_path}")
