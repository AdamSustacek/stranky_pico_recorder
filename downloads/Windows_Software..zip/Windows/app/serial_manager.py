# ============================================================
#  serial_manager.py – neblokující COM komunikace
#  Funguje na Windows (COMx) i Linux (/dev/ttyACMx)
# ============================================================

import serial
import serial.tools.list_ports
import json
import threading
import queue
import time
import glob
import platform

from config import CHUNK_HEADER, CHUNK_BYTES, BAUD_RATE

PICO_VID = 0x2E8A   # Raspberry Pi USB Vendor ID


def find_pico_ports():
    """
    Vrátí seznam (konzole, data) portů Pica.
    Hledá podle VID nebo názvu portu.
    """
    IS_WINDOWS = platform.system() == "Windows"

    # Metoda 1: podle VID
    pico_ports = []
    for p in serial.tools.list_ports.comports():
        if p.vid == PICO_VID:
            pico_ports.append(p.device)

    if len(pico_ports) >= 2:
        pico_ports.sort()
        return pico_ports[0], pico_ports[1]   # konzole, data

    # Metoda 2: podle názvu na Linuxu
    if not IS_WINDOWS:
        acm = sorted(glob.glob("/dev/ttyACM*"))
        if len(acm) >= 2:
            return acm[0], acm[1]
        elif len(acm) == 1:
            return acm[0], acm[0]

    # Metoda 3: vrať všechny COM porty
    all_ports = sorted([p.device for p in serial.tools.list_ports.comports()])
    if len(all_ports) >= 2:
        return all_ports[0], all_ports[1]
    elif len(all_ports) == 1:
        return all_ports[0], all_ports[0]

    return None, None


def list_all_ports():
    """Vrátí seznam všech dostupných portů."""
    ports = sorted([p.device for p in serial.tools.list_ports.comports()])
    if platform.system() != "Windows":
        acm = sorted(glob.glob("/dev/ttyACM*"))
        for p in acm:
            if p not in ports:
                ports.append(p)
    return ports


class SerialManager:
    """Neblokující správa sériového portu v samostatném vlákně."""

    def __init__(self, on_audio=None, on_event=None, on_status=None):
        self.on_audio  = on_audio
        self.on_event  = on_event
        self.on_status = on_status

        self._ser       = None
        self._running   = False
        self._thread    = None
        self._raw_buf   = bytearray()
        self._json_buf  = bytearray()
        self._cmd_queue = queue.Queue()
        self._in_pcm    = False
        self._pcm_want  = 0

    # ── Veřejné API ──────────────────────────────────────────

    def connect(self, port):
        try:
            self._ser = serial.Serial(
                port, baudrate=BAUD_RATE,
                timeout=0, write_timeout=1
            )
            self._running = True
            self._raw_buf  = bytearray()
            self._json_buf = bytearray()
            self._thread = threading.Thread(
                target=self._loop, daemon=True)
            self._thread.start()
            time.sleep(0.5)
            self._notify(f"Připojeno: {port}")
            return True
        except Exception as e:
            self._notify(f"Chyba: {e}")
            return False

    def disconnect(self):
        self._running = False
        try:
            if self._ser and self._ser.is_open:
                self._ser.close()
        except Exception:
            pass
        self._ser = None
        self._notify("Odpojeno")

    def send(self, cmd: str):
        self._cmd_queue.put(cmd)

    def is_connected(self):
        return self._ser is not None and self._ser.is_open

    @property
    def port(self):
        return self._ser.port if self._ser else None

    # ── Smyčka ───────────────────────────────────────────────

    def _loop(self):
        while self._running:
            # Odesílání příkazů
            while not self._cmd_queue.empty():
                try:
                    cmd = self._cmd_queue.get_nowait()
                    if self._ser and self._ser.is_open:
                        self._ser.write((cmd + "\n").encode())
                except Exception:
                    pass

            # Příjem
            try:
                n = self._ser.in_waiting if self._ser else 0
            except Exception as e:
                self._notify(f"Port ztracen: {e}")
                self._running = False
                break

            if n > 0:
                self._parse(self._ser.read(n))
            else:
                time.sleep(0.001)

    def _parse(self, data: bytes):
        self._raw_buf += data
        while self._raw_buf:
            if self._in_pcm:
                if len(self._raw_buf) >= self._pcm_want:
                    pcm = bytes(self._raw_buf[:self._pcm_want])
                    self._raw_buf = self._raw_buf[self._pcm_want:]
                    self._in_pcm = False
                    if self.on_audio:
                        self.on_audio(pcm)
                else:
                    break
            else:
                idx = self._raw_buf.find(CHUNK_HEADER)
                if idx == -1:
                    keep = min(3, len(self._raw_buf))
                    self._process_text(self._raw_buf[:-keep] if keep else self._raw_buf)
                    self._raw_buf = self._raw_buf[-keep:] if keep else bytearray()
                    break
                if idx > 0:
                    self._process_text(self._raw_buf[:idx])
                    self._raw_buf = self._raw_buf[idx:]
                if len(self._raw_buf) < len(CHUNK_HEADER):
                    break
                self._raw_buf = self._raw_buf[len(CHUNK_HEADER):]
                self._in_pcm  = True
                self._pcm_want = CHUNK_BYTES

    def _process_text(self, data: bytearray):
        self._json_buf += data
        while b"\n" in self._json_buf:
            idx  = self._json_buf.index(b"\n")
            line = self._json_buf[:idx].decode("utf-8", "ignore").strip()
            self._json_buf = self._json_buf[idx + 1:]
            if line:
                try:
                    obj = json.loads(line)
                    if self.on_event:
                        self.on_event(obj)
                except Exception:
                    pass

    def _notify(self, msg):
        if self.on_status:
            self.on_status(msg)
